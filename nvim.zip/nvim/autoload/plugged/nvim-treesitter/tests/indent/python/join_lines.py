a = 2 \
    + 2

b = 'hello' \
    'world'

c = lambda x: \
    x + 3
